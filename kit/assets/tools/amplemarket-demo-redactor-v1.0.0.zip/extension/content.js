// Amplemarket Demo Redactor — content script.
// Redacts sensitive data on app.amplemarket.com while recording a demo.
// Toggle via the popup; state lives in chrome.storage.local.redactEnabled.

(() => {
  'use strict';

  const STORAGE_KEY = 'redactEnabled';

  // --- Config -----------------------------------------------------------------

  // Currency is only redacted INSIDE these regions ("targeted only").
  const CURRENCY_SCOPES = [
    '[data-testid="opportunities-cell"]',
    '[data-testid="crm-opportunity-details-content"]',
    '[data-testid^="opened-opportunit"]',
    '[data-testid^="closed-opportunit"]',
    '[data-testid="opened-more-opportunities-total"]',
    '[aria-label="insights"]',
  ];
  // Funding is intentionally NOT scoped — those amounts stay visible in demos.

  // Matches "$1,000", "$2.5M", "$500K", "$5 million", etc. Full words must come
  // before [KMB] in the alternation, or the i-flag lets [KMB] eat the "m" of
  // "million" and leave "illion" behind.
  const CURRENCY_RE = /\$\s?\d[\d,]*(?:\.\d+)?\s?(?:thousand|million|billion|trillion|[KMB])?/gi;
  const EMAIL_RE = /([A-Z0-9._%+-]+)@([A-Z0-9.-]+\.[A-Z]{2,})/gi;
  // Phone candidate: 7+ digits with optional + and . - ( ) space separators.
  // Comma is intentionally excluded so comma-grouped numbers aren't matched.
  const PHONE_RE = /\+?\d(?:[\s().-]?\d){6,}/g;

  const KEEP_EMAIL_DOMAINS = ['amplemarket.com', 'amplemarketapp.com'];

  // Currency is scoped to targeted regions only inside the Amplemarket app.
  // On other matched hosts (Salesforce Lightning) there are no stable hooks,
  // so redact every dollar amount page-wide instead.
  const IS_AMPLEMARKET_APP = location.hostname === 'app.amplemarket.com';

  // Admin / internal-only UI hidden while enabled. Hiding the impersonation
  // portal container removes the account switcher and every admin button it
  // holds; the aria-labels are belt-and-suspenders.
  const HIDE_SELECTORS = [
    '#impersonate-top-nav-bar',
    '[aria-label="Click to open account"]',
    '[aria-label="Click to open user"]',
    '[aria-label="Click to copy current user link"]',
    '[aria-label="Click to return to your account"]',
    '[aria-label="Click to clear frontend version"]',
  ];

  const SKIP_TAGS = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION',
  ]);

  // With all_frames:true the script also runs inside the app.amplemarket.com
  // iframe that the LinkedIn extension embeds (.../linkedin_hook). Redaction
  // runs in every such frame, but only show the indicator dot in the top tab
  // and in that LinkedIn panel frame — not in every nested app iframe.
  const SHOW_BADGE = window.top === window.self ||
    location.pathname.startsWith('/linkedin_hook');

  // --- State ------------------------------------------------------------------

  let enabled = false;
  let observer = null;
  const touchedNodes = new Set();   // text nodes we changed (carry node.__amOrig)
  const touchedAnchors = new Set(); // anchors whose href we changed (el.__amOrigHref)
  const touchedInputs = new Set();  // input/textarea we changed (carry el.__amOrigValue)
  let pendingRoots = [];
  let flushScheduled = false;

  // --- Replacers --------------------------------------------------------------

  function replaceCurrency(text) {
    return text.replace(CURRENCY_RE, () => '$XX');
  }

  function isKeptEmailDomain(domain) {
    const d = domain.toLowerCase();
    return KEEP_EMAIL_DOMAINS.some((k) => d === k || d.endsWith('.' + k));
  }

  function replaceEmail(text) {
    return text.replace(EMAIL_RE, (match, _local, domain) =>
      isKeptEmailDomain(domain) ? match : 'xxxx@' + domain
    );
  }

  function maskPhone(match) {
    const trimmed = match.trim();
    // Don't mask dates / datetimes: 2026-09-15, 2026-09-15 12:00, 09-15-2026.
    if (/^\d{4}-\d{1,2}-\d{1,2}/.test(trimmed)) return match;
    if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(trimmed)) return match;
    const digitIdx = [];
    for (let i = 0; i < match.length; i++) {
      const c = match[i];
      if (c >= '0' && c <= '9') digitIdx.push(i);
    }
    // Phone numbers are 7–15 digits (E.164 max is 15); outside that, leave it.
    if (digitIdx.length < 7 || digitIdx.length > 15) return match;
    const chars = match.split('');
    for (const i of digitIdx.slice(-4)) chars[i] = 'X';
    return chars.join('');
  }

  function replacePhone(text) {
    return text.replace(PHONE_RE, maskPhone);
  }

  // --- Scope helpers ----------------------------------------------------------

  function shouldSkip(node) {
    let el = node.parentElement;
    while (el) {
      if (SKIP_TAGS.has(el.tagName)) return true;
      if (el.isContentEditable) return true;
      if (el.id === 'am-redact-badge') return true;
      el = el.parentElement;
    }
    return false;
  }

  function inCurrencyScopeEl(el) {
    if (!IS_AMPLEMARKET_APP) return true; // page-wide on Salesforce etc.
    if (!el) return false;
    for (const sel of CURRENCY_SCOPES) {
      if (el.closest(sel)) return true;
    }
    return false;
  }

  function inCurrencyScope(node) {
    return inCurrencyScopeEl(node.parentElement);
  }

  // --- Node processing --------------------------------------------------------

  function processTextNode(node) {
    if (node.__amOrig !== undefined) return; // already redacted
    const original = node.nodeValue;
    if (!original || !original.trim()) return;
    if (shouldSkip(node)) return;

    let out = original;
    if (out.indexOf('$') !== -1 && inCurrencyScope(node)) out = replaceCurrency(out);
    out = replaceEmail(out);
    out = replacePhone(out);

    if (out !== original) {
      node.__amOrig = original;
      node.nodeValue = out;
      touchedNodes.add(node);
    }
  }

  function processAnchor(a) {
    if (a.__amOrigHref !== undefined) return;
    const href = a.getAttribute('href') || '';
    let newHref = href;
    if (/^mailto:/i.test(href)) {
      newHref = href.replace(/^mailto:([^?]*)/i, (m, addr) => 'mailto:' + replaceEmail(addr));
    } else if (/^tel:/i.test(href)) {
      newHref = 'tel:' + replacePhone(href.slice(4));
    }
    if (newHref !== href) {
      a.__amOrigHref = href;
      a.setAttribute('href', newHref);
      touchedAnchors.add(a);
    }
  }

  function processAnchors(root) {
    if (root.matches &&
        (root.matches('a[href^="mailto:"]') || root.matches('a[href^="tel:"]'))) {
      processAnchor(root);
    }
    if (root.querySelectorAll) {
      root.querySelectorAll('a[href^="mailto:"], a[href^="tel:"]').forEach(processAnchor);
    }
  }

  // Email/phone shown inside form fields (e.g. the LinkedIn panel's contact
  // fields) have no child text nodes, so the text walker misses them. Handle
  // input/textarea values explicitly. Semantic email/tel/url fields are always
  // masked; plain text fields only when read-only, to avoid masking search boxes.
  const REDACT_INPUT_TYPES = new Set(['', 'text', 'email', 'tel', 'url']);
  function processInput(el) {
    if (!el || el.__amOrigValue !== undefined) return;
    const tag = el.tagName;
    if (tag === 'INPUT') {
      const type = (el.getAttribute('type') || '').toLowerCase();
      if (!REDACT_INPUT_TYPES.has(type)) return;
      if ((type === '' || type === 'text') && !(el.readOnly || el.disabled)) return;
    } else if (tag !== 'TEXTAREA') {
      return;
    }
    const original = el.value;
    if (!original || !original.trim()) return;
    let out = replacePhone(replaceEmail(original));
    if (out.indexOf('$') !== -1 && inCurrencyScopeEl(el)) out = replaceCurrency(out);
    if (out !== original) {
      el.__amOrigValue = original;
      el.value = out;
      touchedInputs.add(el);
    }
  }

  function processInputs(root) {
    if (root.tagName === 'INPUT' || root.tagName === 'TEXTAREA') processInput(root);
    if (root.querySelectorAll) root.querySelectorAll('input, textarea').forEach(processInput);
  }

  function walk(root) {
    if (!root) return;
    if (root.nodeType === Node.TEXT_NODE) {
      processTextNode(root);
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE &&
        root.nodeType !== Node.DOCUMENT_NODE &&
        root.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) {
      return;
    }
    // Light-DOM text nodes under root.
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(processTextNode);
    processAnchors(root);
    processInputs(root);
    // Descend into open shadow roots (Salesforce Lightning web components, etc.).
    // Content scripts run in an isolated world, so element.shadowRoot returns the
    // real native shadow root even when the page patches it (Locker/synthetic).
    if (root.shadowRoot) walk(root.shadowRoot);
    const elWalker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null);
    let el;
    while ((el = elWalker.nextNode())) {
      if (el.shadowRoot) walk(el.shadowRoot);
    }
  }

  // --- Observer (handles React re-renders, route changes, lazy tooltips) ------

  function withObserverPaused(fn) {
    if (observer) observer.disconnect();
    try {
      fn();
    } finally {
      if (observer && enabled && document.body) {
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      }
    }
  }

  function onMutations(records) {
    if (!enabled) return;
    for (const r of records) {
      if (r.type === 'characterData') {
        pendingRoots.push(r.target);
      } else if (r.type === 'childList') {
        r.addedNodes.forEach((node) => pendingRoots.push(node));
      }
    }
    scheduleFlush();
  }

  function scheduleFlush() {
    if (flushScheduled) return;
    flushScheduled = true;
    requestAnimationFrame(() => {
      flushScheduled = false;
      const roots = pendingRoots;
      pendingRoots = [];
      if (!enabled || !roots.length) return;
      withObserverPaused(() => {
        for (const root of roots) {
          if (!root || !root.isConnected) continue;
          if (root.nodeType === Node.TEXT_NODE) {
            // React rewrote this text node — drop our stale cache and redo it.
            delete root.__amOrig;
            touchedNodes.delete(root);
            processTextNode(root);
          } else {
            walk(root);
          }
        }
      });
    });
  }

  // --- Hide admin UI / badge --------------------------------------------------

  function setHideStyle(on) {
    let style = document.getElementById('am-redact-hide');
    if (on && !style) {
      style = document.createElement('style');
      style.id = 'am-redact-hide';
      style.textContent = HIDE_SELECTORS.join(',\n') + ' { display: none !important; }';
      (document.head || document.documentElement).appendChild(style);
    } else if (!on && style) {
      style.remove();
    }
  }

  function setBadge(on) {
    let badge = document.getElementById('am-redact-badge');
    if (on && !badge && SHOW_BADGE) {
      badge = document.createElement('div');
      badge.id = 'am-redact-badge';
      document.documentElement.appendChild(badge);
    } else if (!on && badge) {
      badge.remove();
    }
  }

  // --- Restore ----------------------------------------------------------------

  function restoreAll() {
    for (const node of touchedNodes) {
      if (node.__amOrig !== undefined) {
        try { node.nodeValue = node.__amOrig; } catch (e) { /* detached */ }
        delete node.__amOrig;
      }
    }
    touchedNodes.clear();
    for (const a of touchedAnchors) {
      if (a.__amOrigHref !== undefined) {
        try { a.setAttribute('href', a.__amOrigHref); } catch (e) { /* detached */ }
        delete a.__amOrigHref;
      }
    }
    touchedAnchors.clear();
    for (const el of touchedInputs) {
      if (el.__amOrigValue !== undefined) {
        try { el.value = el.__amOrigValue; } catch (e) { /* detached */ }
        delete el.__amOrigValue;
      }
    }
    touchedInputs.clear();
  }

  // --- Enable / disable -------------------------------------------------------

  function enable() {
    if (enabled || !document.body) return;
    enabled = true;
    if (!observer) observer = new MutationObserver(onMutations);
    setHideStyle(true);
    setBadge(true);
    withObserverPaused(() => walk(document.body));
  }

  function disable() {
    if (!enabled) return;
    enabled = false;
    if (observer) observer.disconnect();
    pendingRoots = [];
    setHideStyle(false);
    setBadge(false);
    restoreAll();
  }

  function applyState(on) {
    if (on) enable();
    else disable();
  }

  // --- Init -------------------------------------------------------------------

  function init() {
    chrome.storage.local.get(STORAGE_KEY, (res) => applyState(!!res[STORAGE_KEY]));
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && STORAGE_KEY in changes) {
        applyState(!!changes[STORAGE_KEY].newValue);
      }
    });
  }

  if (document.body) init();
  else document.addEventListener('DOMContentLoaded', init, { once: true });
})();
