const STORAGE_KEY = 'redactEnabled';
const toggle = document.getElementById('toggle');
const status = document.getElementById('status');

function render(on) {
  toggle.checked = on;
  status.textContent = on ? 'On — redacting' : 'Off';
  status.classList.toggle('on', on);
}

chrome.storage.local.get(STORAGE_KEY, (res) => render(!!res[STORAGE_KEY]));

toggle.addEventListener('change', () => {
  const on = toggle.checked;
  chrome.storage.local.set({ [STORAGE_KEY]: on });
  render(on);
});
